#pragma once
#include <iostream>

void helloName(std::string);
