#include <iostream>
#include "functions.h"

using namespace std;

// Functions are similar but there's differences
// - the return type is explicit
// - only return one value
// - if you don't return, the type is "void"
// parameter passing: depending on what you need to do
// by value (default) makes a copy and preserves the original
// by reference: will make the changes on the original
// by pointer: you don't pass a parameter but its memory address instead

// Also functions need to either be declared above main
// Or their signature needs declared above main and their 
// can be below
// Or the signatures can be in a different file

// Typical function returning adding two integers
// And returning the result
int addNumbers(int a, int b)
{
	return a + b;
}

// Function overloading: you can have the same name
// and signature for different types
double addNumbers(double a, double b)
{
	return a + b;
}

// Example of void function
// No return - correct term for that is procedure
void haiku()
{
	cout << "Yesterday it worked." << endl;
	cout << "Today it is not working." << endl;
	cout << "Coding is like that." << endl;
}


// Declaration of function signature for hello
void sayHello(void);

// This function takes your age, doubles it up, adds 10
int doubleAge(int age)
{
	return age * 2 + 10;
}

// By reference
void doubleAgeByRef(int& age)
{
	age = age * 2 + 10;
	cout << "new age is " << age << endl;
}

// In C there's no reference we would use pointers
void doubleAgeByPointer(int* age)
{
	*age = *age * 2 + 10;
	cout << "new age is " << *age << endl;
}

int main()
{
	cout << addNumbers(5, 6) << endl;
	cout << addNumbers(5.5, 6.) << endl;

	haiku();
	sayHello();

	string name = "Aurelien";
	helloName(name);

	// Passing parameters by value
	// In this scenario we make a copy of age and
	// The original is untouched
	int age = 40;
	cout << "age before " << age << endl;
	cout << "age after " << doubleAge(40) << endl;
	cout << "age before " << age << endl;

	int age2 = 40;
	cout << "age2 before " << age2 << endl;
	doubleAgeByRef(age2);
	cout << "age2 after " << age2 << endl;

	int age3 = 40;
	cout << "age3 before " << age3 << endl;
	doubleAgeByPointer(&age3);
	cout << "age3 after " << age3 << endl;

	return 0;
}

void sayHello()
{
	cout << "Hello" << endl;
}

void helloName(string name)
{
	cout << "Hello " << name << endl;
}

